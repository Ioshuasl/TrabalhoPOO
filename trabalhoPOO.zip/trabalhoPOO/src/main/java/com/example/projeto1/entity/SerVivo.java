package com.example.projeto1.entity;

public class SerVivo {
    
    private String sangue;

    public SerVivo(String sangue) {
       this.sangue = sangue;
    }


    public String getSangue() {
        return sangue;
    }

    public void setSangue(String sangue) {
        this.sangue = sangue;
    }
}
